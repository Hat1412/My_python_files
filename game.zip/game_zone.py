import random
from tkinter import *
import os,time
from PIL import Image,ImageTk
from tkinter.messagebox import showinfo
import string

COLORS = ["white","red","blue","cyan","yellow","pink"]
game_zone = Tk()
game_zone.title("WELCOME TO THE GAMEZONE")
image = Image.open(r'rock.png')
image = image.resize((game_zone.winfo_width(),game_zone.winfo_height()), Image.ANTIALIAS)
r_photo = ImageTk.PhotoImage(image)
l = ["GUESSING_GAME","TIC_TAC_TOE","ROCK_PAPER_SCISSORS","RANDOM_NUMBER_GENERATOR","snake"]

def create(te,cmd,r,c):
    def run():
        os.startfile(f"{cmd}.py")
    Button(game_zone,bg = random.choice(COLORS),text = te.upper(),fg = "black",command=run,height = 5,width = 25).grid(row = r,column = c,sticky="nwes")

t = (0,0)
change = 10
for i in l: 
    row = t[0]+change
    column = t[1]
    if row > game_zone.winfo_height():
        column = t[1]+change
    change+=20
    create(str(i),i,row,column)

mainloop()