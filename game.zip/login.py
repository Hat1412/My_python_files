from tkinter import *
import os
from openpyxl import load_workbook
from tkinter.messagebox import showinfo
import string
root = Tk()
root.rowconfigure((0, 1, 2, 3), weight=1)
root.columnconfigure((0, 1, 2, 3), weight=1)
root.title("LOCK SCREEN")
root.config(bg = "cyan")
Label(root,text = "You can register for free:",font = ("Helvetca",29),bg = "blue",fg = "red").pack(side = "top")

def game_zone():
    os.startfile(r"game_zone.py")
def login():
    try:
        root.destroy()
    except:
        pass
    login_screen = Tk()
    login_screen.title("Login_Screen")
    Label(login_screen,text = "Username:").pack() 
    Username = Entry(login_screen)
    Username.pack()
    Label(login_screen,text = "Password(>8)*:").pack() 
    Password = Entry(login_screen,show = "*")
    Password.pack()

    def check():
        wb = load_workbook(r"D:\ACHU\PYTHON\test\data.xlsx")
        s = wb.active
        i = 2
        login = False
        while i < 120:
            if(s[f"A{i}"].value == str(Username.get())):
                if(s[f"B{i}"].value) == str(Password.get()):
                    showinfo("WELCOME","Login Complete")
                    login_screen.destroy()
                    game_zone()
                    login = True
                    break
            else:
                i+=1

        if login == False:
            showinfo("USERNAME OR PASSWORD WRONG","USERNAME OR PASSWORD WRONG")

    Button(login_screen,text= "Submit",command = check).pack()
    

def register():
    try:
        root.destroy()
        login_screen.destroy()
    except:
        pass
    register_screen = Tk()
    register_screen.title("Register_Screen")
    Label(register_screen,text = "Username(>8)*").pack() 
    Username = Entry(register_screen)
    Username.pack()
    Label(register_screen,text = "Password(>8)*").pack() 
    Password = Entry(register_screen)
    Password.pack()
    Label(register_screen,text=" * means IMPORTANT ").pack(side="bottom")

    def add_to_file():
        if(len(str(Username.get())) < 8):
            showinfo("Username not long enough","Username not long enough")
        if(len(str(Password.get())) < 8):
            showinfo("Password not long enough","Password not long enough")
        else:
            wb = load_workbook(r"D:\ACHU\PYTHON\test\data.xlsx")
            s = wb.active
            for i in range(1,500):
                if s[f"A{i}"].value == None:
                    s[f"A{i}"] = str(Username.get())
                    s[f"B{i}"] = str(Password.get())
                    break
            wb.save(r"D:\ACHU\PYTHON\test\data.xlsx")
            showinfo("REGISTRATION COMPLETE","LOGIN WITH YOUR NEW USERNAME AND PASSWORD IN THE LOGIN SCREEN")
            register_screen.destroy()
            login()
    Button(register_screen,text="Submit",command= add_to_file).pack()

Button(root,text = "LOGIN",font = ("Helvetca",29),command= login).pack()
Button(root,text = "REGISTER",font = ("Helvetca",29),command = register).pack()
root.bind('<Return>', login)
mainloop()
