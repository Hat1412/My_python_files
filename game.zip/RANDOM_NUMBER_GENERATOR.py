from tkinter import *
import random
root = Tk()
num = Label(root,font = ("Calibri",29))
num.pack()
Label(root,text = "Enter Lower limit:",font = ("Calibri",21)).pack()
s = Entry(root,font = ("Calibri",21))
s.pack()
Label(root,text = "Enter Upper limit:",font = ("Calibri",21)).pack()
s2 = Entry(root,font = ("Calibri",21))
s2.pack()
def ge():
    num.config(text = random.randint(int(s.get()),int(s2.get())))
Button(root,font = ("Calibri",29),bg = "pink",text = "GENERATE RANDOM NUMBER",command = ge).pack()

mainloop()