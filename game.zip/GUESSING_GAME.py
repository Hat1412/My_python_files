import random,time
from tkinter import *
root = Tk()
root.geometry("500x600")
Label(root,text = "Enter your guess(1-100):",font = ("Calibri",19)).pack(side = "top")
l = Label(root,font = ("Calibri",15))
l.pack()
num = random.randint(0,100)
turns = 0
running = True
g = Entry(root,font = ("Calibri",15))
g.pack()
turn_l = Label(root,font = ("Calibri",15))
turn_l.pack()

count = 100
def check():
    global count
    if count == 0:
        if (sub['state'] == NORMAL):
            sub['state'] = DISABLED

    if(int(g.get()) == num):
        global turns
        l.configure(text = "BANZAI")
        turn_l.config(text = str(7-turns))
        count = 0
    elif(int(g.get())<num):
        l.configure(text = "THE NUMBER TO BE GUESSED IS LARGER")
        turns+=1
        turn_l.config(text = str(7-turns))
    else:
        l.configure(text = "THE NUMBER TO BE GUESSED IS SMALLER")
        turns+=1
        turn_l.config(text = f"TURNS REMAINING: {str(7-turns)}")
    if(g!=num and turns>=7):
       l.config(text=f'OUT OF TURNS,THE NUMBER WAS {num}')
       count = 0

sub = Button(root,text = "CHECK NUMBER",command = check)
sub.pack()

mainloop()