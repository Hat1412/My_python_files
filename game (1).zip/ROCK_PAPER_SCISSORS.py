#_____________________________ROCK PAPER SCISSORS_____________________________
import random 
from tkinter import *
from PIL import Image,ImageTk
import time
root = Tk()
root.configure(bg = '#2e2bda')
main = ["rock","paper","scissor"]
c_p = 0
p_p = 0
#==============================IMAGES==================================

image = Image.open(r'rock.png')
image = image.resize((200,120), Image.ANTIALIAS)
r_photo = ImageTk.PhotoImage(image)
#--------------------------------------------------------
image = Image.open("paper.png")
image = image.resize((200,120), Image.ANTIALIAS)
p_photo = ImageTk.PhotoImage(image)
#---------------------------------------------------------
image = Image.open("scissor.png")
image = image.resize((200,120), Image.ANTIALIAS)
s_photo = ImageTk.PhotoImage(image)
#---------------------------------------------------------
image = Image.open("pbutton.png")
image = image.resize((200,120), Image.ANTIALIAS)
p_button = ImageTk.PhotoImage(image)
#--------------------------------------------------------
image = Image.open(r"rock_button.png")
image = image.resize((200,120), Image.ANTIALIAS)
r_button = ImageTk.PhotoImage(image)
#-----------------------------------------------------------"""
image = Image.open("sbutton.png")
image = image.resize((200,120), Image.ANTIALIAS)
s_button = ImageTk.PhotoImage(image)

#___________________________________________________________________
def p():
    pl = "paper"
    Label(root,image = p_photo).grid(row = 2, column = 5)

    a = random.choice(main)
    if(a == "rock"):
        Label(root,image = r_photo).grid(row = 2, column = 3)
    if(a == "paper"):
        Label(root,image = p_photo).grid(row = 2, column = 3)
    if(a == "scissor"):
        Label(root,image = s_photo).grid(row = 2, column = 3)
    global c_p
    
    global p_p
   
    if pl == a:
        popupmsg("Tie")
    elif pl == "paper":
        if a == "scissors":
            c_p+=1
            popupmsg("You lose!")
            
        else:
            p_p+=1
            popupmsg("You win!")
            
            
def s():
    pl = "scissors"
    Label(root,image = s_photo).grid(row = 2, column = 5)
    a = random.choice(main)
    if(a == "rock"):
        Label(root,image = r_photo).grid(row = 2, column = 3)
    if(a == "paper"):
        Label(root,image = p_photo).grid(row = 2, column = 3)
    if(a == "scissor"):
        Label(root,image = s_photo).grid(row = 2, column = 3)
    global c_p
    
    global p_p
    
    if pl == a:
        popupmsg("Tie")
    elif pl == "scissors":
        if a == "rock":
            c_p+=1
            popupmsg("You lose...")
            
                       
        else:
            p_p+=1
            popupmsg("You win!")
            

def r():
        pl = "rock"
        Label(root,image = r_photo).grid(row = 2, column = 5)

        a = random.choice(main)
        if(a == "rock"):
            Label(root,image = r_photo).grid(row = 2, column = 3)
        if(a == "paper"):
            Label(root,image = p_photo).grid(row = 2, column = 3)
        if(a == "scissor"):
            Label(root,image = s_photo).grid(row = 2, column = 3)
        global c_p
        
        global p_p
        
        if pl == a:
            popupmsg("Tie")

        elif pl == "rock":
            if a == "paper":
                c_p+=1
                popupmsg("You lose...")
                
            else:
                p_p+=1
                popupmsg("You win!")
               
               
                

def popupmsg(msg):
    Label(root,text = msg,width = 15,font = ("Helvetica", 27)).grid(row = 5,column = 4)
    Label(root,text =("computer score:",c_p),width = 15,font = ("Helvetica", 27)).grid(row = 6,column = 4)
    Label(root,text =("player score:",p_p),width = 15,font = ("Helvetica", 27)).grid(row = 7,column = 4)
    

#______________________________Add buttons and title__________________________________________________        
title = Label(root,text = "Rock Paper and Scissors",font = ('Calibri',30)).grid(row = 0,column = 4)
rock = Button(root,image = r_button,command = r).grid(row = 12,column = 4)
paper = Button(root,image = p_button,command = p).grid(row = 12,column = 3)
scissors = Button(root,image = s_button,command = s).grid(row = 12,column = 5)

mainloop()
